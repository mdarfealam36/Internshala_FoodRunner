package com.example.foodrunner.model

class HomeRestaurant (
    val restaurantId: String,
    val restaurantName : String,
    val restaurantRating: String,
    val restaurantPrice: String,
    val restaurantImage: String
)